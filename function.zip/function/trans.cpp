#include<iostream>
using namespace std;

void trans()
{
    int a[9],num;

    cout<<"��ӭ�����������Ϣϵͳ"<<endl<<"������0-255֮�������"<<endl;

    while(cin>>num)
    {
        if(0<=num&&255>=num)

        {

            for(int i = 7; i >= 0; i--)

            {
                a[i]=(num>>i&1);
            }

            if(a[7]==0&&num<128)
            {
                cout<<"boy"<<endl;

                cout<<"ѧ���ǣ�"<<num<<endl;

                cout<<"�����ǣ�";

                for(int i = 7; i >=0; i--)

                {
                    cout<<a[i];
                }

                cout<<endl;
            }

            else

            {
                cout<<"girl"<<endl;

                cout<<"ѧ���ǣ�"<<num-128<<endl;

                cout<<"�����ǣ�";

                for(int i = 7; i >=0; i--)

                {
                    cout<<a[i];
                }

                cout<<endl;
            }
        }
       else

        {
            cout<<"error"<<endl;
        }

      cout<<endl<<"������0-255֮�������"<<endl;

        }
}

int main()
{
    trans();
    return 0;
}
