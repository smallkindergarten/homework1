#include<iostream>
using namespace std;

struct stack
{
    int max;
    int t;
    int *data;
};

typedef struct stack *pstruct;

pstruct createmptystack(int m);
void pushstack(pstruct pastack,int x);
void outstack (pstruct pastack);
int take_top_stack(pstruct pastack);

int main()
{
    int item=0,num;
    cout<<"please enter the exact num and the data "<<endl;
    cin>>num;
    cout<<endl;
    pstruct pastack=createmptystack(num);
    for(int i=0;i<num;i++)
    {
        cin>>item;
        pushstack(pastack,item);
        cout<<(pastack->t)<<endl;
        cout<<endl;
    }
    cout<<"here is the output"<<endl;
    for(int i=0;i<num;i++)
    {
        item=take_top_stack(pastack);
        cout<<item<<endl;
        outstack (pastack);
    }
    return 0;
}

pstruct createmptystack(int m)
{
    pstruct pastack=new struct stack;

    if(pastack!=NULL)
    {
        pastack->data=new int(m);
    if(pastack->data)
    {
        pastack->max=m;
        pastack->t=-1;
        return pastack;
    }
    else delete pastack;
    }
    cout << "out" <<endl;
    return NULL;
}

void pushstack(pstruct pastack,int x)
{
    if(pastack->t >= (pastack->max)-1)
    {
        cout<<"out"<<endl;
    }
    else
    {
        pastack->t=pastack->t+1;
        pastack->data[pastack->t]=x;
    }
}

void outstack (pstruct pastack)
{
    if(pastack->t==-1)
    {
        cout<<"wu"<<endl;
    }
    else
    {
        pastack->t=pastack->t-1;
    }
}

int take_top_stack(pstruct pastack)
{
    if(pastack->t==-1)
    {
        cout<<"empty!"<<endl;
    }
    else
    {
        return (pastack->data[pastack->t]);
    }
}


