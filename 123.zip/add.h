#ifndef _ADD_H_
#define _ADD_H_

int add(int a);

#endif
